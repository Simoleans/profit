<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = [
            [
                'name' => 'Administrador Sistema',
                'password' => Hash::make('admin123'),
                'rol' => 0,
                'co_ven' => 'ADM001',
            ]
        ];

        foreach ($users as $user) {
            User::create($user);
        }
    }
}
