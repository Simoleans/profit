import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\HeaderController::data
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
export const data = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})

data.definition = {
    methods: ["get","head"],
    url: '/debug-user-data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::data
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
data.url = (options?: RouteQueryOptions) => {
    return data.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::data
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
data.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::data
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
data.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::data
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
    const dataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: data.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::data
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
        dataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::data
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
        dataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    data.form = dataForm
const user = {
    data: Object.assign(data, data),
}

export default user