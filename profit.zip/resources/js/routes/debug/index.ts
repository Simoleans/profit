import user from './user'
const debug = {
    user: Object.assign(user, user),
}

export default debug