import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
export const clients = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clients.url(options),
    method: 'get',
})

clients.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/stats/clients',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
clients.url = (options?: RouteQueryOptions) => {
    return clients.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
clients.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clients.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
clients.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clients.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
    const clientsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clients.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
        clientsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clients.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
        clientsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clients.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clients.form = clientsForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
export const retenciones = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: retenciones.url(options),
    method: 'get',
})

retenciones.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/stats/retenciones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
retenciones.url = (options?: RouteQueryOptions) => {
    return retenciones.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
retenciones.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: retenciones.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
retenciones.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: retenciones.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
    const retencionesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: retenciones.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
        retencionesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: retenciones.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
        retencionesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: retenciones.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    retenciones.form = retencionesForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
export const cuentasPorCobrar = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cuentasPorCobrar.url(options),
    method: 'get',
})

cuentasPorCobrar.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/stats/cuentas-por-cobrar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
cuentasPorCobrar.url = (options?: RouteQueryOptions) => {
    return cuentasPorCobrar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
cuentasPorCobrar.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cuentasPorCobrar.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
cuentasPorCobrar.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cuentasPorCobrar.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
    const cuentasPorCobrarForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: cuentasPorCobrar.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
        cuentasPorCobrarForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cuentasPorCobrar.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
        cuentasPorCobrarForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cuentasPorCobrar.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    cuentasPorCobrar.form = cuentasPorCobrarForm
const stats = {
    clients: Object.assign(clients, clients),
retenciones: Object.assign(retenciones, retenciones),
cuentasPorCobrar: Object.assign(cuentasPorCobrar, cuentasPorCobrar),
}

export default stats