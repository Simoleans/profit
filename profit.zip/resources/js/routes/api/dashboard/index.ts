import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import stats from './stats'
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
export const promotionArticles = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: promotionArticles.url(options),
    method: 'get',
})

promotionArticles.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/promotion-articles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
promotionArticles.url = (options?: RouteQueryOptions) => {
    return promotionArticles.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
promotionArticles.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: promotionArticles.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
promotionArticles.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: promotionArticles.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
    const promotionArticlesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: promotionArticles.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
        promotionArticlesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: promotionArticles.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
        promotionArticlesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: promotionArticles.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    promotionArticles.form = promotionArticlesForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
export const orderStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orderStats.url(options),
    method: 'get',
})

orderStats.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/order-stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
orderStats.url = (options?: RouteQueryOptions) => {
    return orderStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
orderStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orderStats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
orderStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orderStats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
    const orderStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: orderStats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
        orderStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: orderStats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
        orderStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: orderStats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    orderStats.form = orderStatsForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
export const clientesSinPedidos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clientesSinPedidos.url(options),
    method: 'get',
})

clientesSinPedidos.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/clientes-sin-pedidos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
clientesSinPedidos.url = (options?: RouteQueryOptions) => {
    return clientesSinPedidos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
clientesSinPedidos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clientesSinPedidos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
clientesSinPedidos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clientesSinPedidos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
    const clientesSinPedidosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clientesSinPedidos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
        clientesSinPedidosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clientesSinPedidos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
        clientesSinPedidosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clientesSinPedidos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clientesSinPedidos.form = clientesSinPedidosForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
export const clientesInactivos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clientesInactivos.url(options),
    method: 'get',
})

clientesInactivos.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/clientes-inactivos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
clientesInactivos.url = (options?: RouteQueryOptions) => {
    return clientesInactivos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
clientesInactivos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clientesInactivos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
clientesInactivos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clientesInactivos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
    const clientesInactivosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clientesInactivos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
        clientesInactivosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clientesInactivos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
        clientesInactivosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clientesInactivos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clientesInactivos.form = clientesInactivosForm
const dashboard = {
    stats: Object.assign(stats, stats),
promotionArticles: Object.assign(promotionArticles, promotionArticles),
orderStats: Object.assign(orderStats, orderStats),
clientesSinPedidos: Object.assign(clientesSinPedidos, clientesSinPedidos),
clientesInactivos: Object.assign(clientesInactivos, clientesInactivos),
}

export default dashboard