import dashboard from './dashboard'
const api = {
    dashboard: Object.assign(dashboard, dashboard),
}

export default api