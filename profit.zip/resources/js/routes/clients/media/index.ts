import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientController::download
 * @see app/Http/Controllers/ClientController.php:185
 * @route '/clients/media/{mediaId}/download'
 */
export const download = (args: { mediaId: string | number } | [mediaId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/clients/media/{mediaId}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientController::download
 * @see app/Http/Controllers/ClientController.php:185
 * @route '/clients/media/{mediaId}/download'
 */
download.url = (args: { mediaId: string | number } | [mediaId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mediaId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    mediaId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mediaId: args.mediaId,
                }

    return download.definition.url
            .replace('{mediaId}', parsedArgs.mediaId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientController::download
 * @see app/Http/Controllers/ClientController.php:185
 * @route '/clients/media/{mediaId}/download'
 */
download.get = (args: { mediaId: string | number } | [mediaId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientController::download
 * @see app/Http/Controllers/ClientController.php:185
 * @route '/clients/media/{mediaId}/download'
 */
download.head = (args: { mediaId: string | number } | [mediaId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientController::download
 * @see app/Http/Controllers/ClientController.php:185
 * @route '/clients/media/{mediaId}/download'
 */
    const downloadForm = (args: { mediaId: string | number } | [mediaId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientController::download
 * @see app/Http/Controllers/ClientController.php:185
 * @route '/clients/media/{mediaId}/download'
 */
        downloadForm.get = (args: { mediaId: string | number } | [mediaId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientController::download
 * @see app/Http/Controllers/ClientController.php:185
 * @route '/clients/media/{mediaId}/download'
 */
        downloadForm.head = (args: { mediaId: string | number } | [mediaId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const media = {
    download: Object.assign(download, download),
}

export default media