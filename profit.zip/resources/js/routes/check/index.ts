import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\HeaderController::client
 * @see app/Http/Controllers/HeaderController.php:433
 * @route '/check-client'
 */
export const client = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: client.url(options),
    method: 'get',
})

client.definition = {
    methods: ["get","head"],
    url: '/check-client',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::client
 * @see app/Http/Controllers/HeaderController.php:433
 * @route '/check-client'
 */
client.url = (options?: RouteQueryOptions) => {
    return client.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::client
 * @see app/Http/Controllers/HeaderController.php:433
 * @route '/check-client'
 */
client.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: client.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::client
 * @see app/Http/Controllers/HeaderController.php:433
 * @route '/check-client'
 */
client.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: client.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::client
 * @see app/Http/Controllers/HeaderController.php:433
 * @route '/check-client'
 */
    const clientForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: client.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::client
 * @see app/Http/Controllers/HeaderController.php:433
 * @route '/check-client'
 */
        clientForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: client.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::client
 * @see app/Http/Controllers/HeaderController.php:433
 * @route '/check-client'
 */
        clientForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: client.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    client.form = clientForm
const check = {
    client: Object.assign(client, client),
}

export default check