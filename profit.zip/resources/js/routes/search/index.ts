import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\UserController::seller
 * @see app/Http/Controllers/UserController.php:160
 * @route '/search-seller'
 */
export const seller = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: seller.url(options),
    method: 'get',
})

seller.definition = {
    methods: ["get","head"],
    url: '/search-seller',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserController::seller
 * @see app/Http/Controllers/UserController.php:160
 * @route '/search-seller'
 */
seller.url = (options?: RouteQueryOptions) => {
    return seller.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserController::seller
 * @see app/Http/Controllers/UserController.php:160
 * @route '/search-seller'
 */
seller.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: seller.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserController::seller
 * @see app/Http/Controllers/UserController.php:160
 * @route '/search-seller'
 */
seller.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: seller.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserController::seller
 * @see app/Http/Controllers/UserController.php:160
 * @route '/search-seller'
 */
    const sellerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: seller.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserController::seller
 * @see app/Http/Controllers/UserController.php:160
 * @route '/search-seller'
 */
        sellerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: seller.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserController::seller
 * @see app/Http/Controllers/UserController.php:160
 * @route '/search-seller'
 */
        sellerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: seller.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    seller.form = sellerForm
/**
* @see \App\Http\Controllers\HeaderController::clients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
export const clients = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clients.url(options),
    method: 'get',
})

clients.definition = {
    methods: ["get","head"],
    url: '/search-clients',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::clients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
clients.url = (options?: RouteQueryOptions) => {
    return clients.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::clients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
clients.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clients.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::clients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
clients.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clients.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::clients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
    const clientsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clients.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::clients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
        clientsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clients.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::clients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
        clientsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clients.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clients.form = clientsForm
/**
* @see \App\Http\Controllers\HeaderController::articles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
export const articles = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: articles.url(options),
    method: 'get',
})

articles.definition = {
    methods: ["get","head"],
    url: '/search-articles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::articles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
articles.url = (options?: RouteQueryOptions) => {
    return articles.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::articles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
articles.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: articles.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::articles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
articles.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: articles.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::articles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
    const articlesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: articles.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::articles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
        articlesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: articles.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::articles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
        articlesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: articles.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    articles.form = articlesForm
const search = {
    seller: Object.assign(seller, seller),
clients: Object.assign(clients, clients),
articles: Object.assign(articles, articles),
}

export default search