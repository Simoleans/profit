import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
export const clients = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clients.url(options),
    method: 'get',
})

clients.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/stats/clients',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
clients.url = (options?: RouteQueryOptions) => {
    return clients.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
clients.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clients.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
clients.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clients.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
    const clientsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clients.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
        clientsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clients.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clients
 * @see app/Http/Controllers/Api/DashboardStatsController.php:31
 * @route '/api/dashboard/stats/clients'
 */
        clientsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clients.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clients.form = clientsForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
export const retenciones = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: retenciones.url(options),
    method: 'get',
})

retenciones.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/stats/retenciones',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
retenciones.url = (options?: RouteQueryOptions) => {
    return retenciones.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
retenciones.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: retenciones.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
retenciones.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: retenciones.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
    const retencionesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: retenciones.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
        retencionesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: retenciones.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::retenciones
 * @see app/Http/Controllers/Api/DashboardStatsController.php:60
 * @route '/api/dashboard/stats/retenciones'
 */
        retencionesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: retenciones.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    retenciones.form = retencionesForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
export const cuentasPorCobrar = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cuentasPorCobrar.url(options),
    method: 'get',
})

cuentasPorCobrar.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/stats/cuentas-por-cobrar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
cuentasPorCobrar.url = (options?: RouteQueryOptions) => {
    return cuentasPorCobrar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
cuentasPorCobrar.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cuentasPorCobrar.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
cuentasPorCobrar.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cuentasPorCobrar.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
    const cuentasPorCobrarForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: cuentasPorCobrar.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
        cuentasPorCobrarForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cuentasPorCobrar.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::cuentasPorCobrar
 * @see app/Http/Controllers/Api/DashboardStatsController.php:75
 * @route '/api/dashboard/stats/cuentas-por-cobrar'
 */
        cuentasPorCobrarForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cuentasPorCobrar.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    cuentasPorCobrar.form = cuentasPorCobrarForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
export const promotionArticles = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: promotionArticles.url(options),
    method: 'get',
})

promotionArticles.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/promotion-articles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
promotionArticles.url = (options?: RouteQueryOptions) => {
    return promotionArticles.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
promotionArticles.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: promotionArticles.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
promotionArticles.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: promotionArticles.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
    const promotionArticlesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: promotionArticles.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
        promotionArticlesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: promotionArticles.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::promotionArticles
 * @see app/Http/Controllers/Api/DashboardStatsController.php:104
 * @route '/api/dashboard/promotion-articles'
 */
        promotionArticlesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: promotionArticles.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    promotionArticles.form = promotionArticlesForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
export const orderStats = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orderStats.url(options),
    method: 'get',
})

orderStats.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/order-stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
orderStats.url = (options?: RouteQueryOptions) => {
    return orderStats.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
orderStats.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orderStats.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
orderStats.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orderStats.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
    const orderStatsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: orderStats.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
        orderStatsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: orderStats.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::orderStats
 * @see app/Http/Controllers/Api/DashboardStatsController.php:119
 * @route '/api/dashboard/order-stats'
 */
        orderStatsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: orderStats.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    orderStats.form = orderStatsForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
export const clientesSinPedidos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clientesSinPedidos.url(options),
    method: 'get',
})

clientesSinPedidos.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/clientes-sin-pedidos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
clientesSinPedidos.url = (options?: RouteQueryOptions) => {
    return clientesSinPedidos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
clientesSinPedidos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clientesSinPedidos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
clientesSinPedidos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clientesSinPedidos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
    const clientesSinPedidosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clientesSinPedidos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
        clientesSinPedidosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clientesSinPedidos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesSinPedidos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:164
 * @route '/api/dashboard/clientes-sin-pedidos'
 */
        clientesSinPedidosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clientesSinPedidos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clientesSinPedidos.form = clientesSinPedidosForm
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
export const clientesInactivos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clientesInactivos.url(options),
    method: 'get',
})

clientesInactivos.definition = {
    methods: ["get","head"],
    url: '/api/dashboard/clientes-inactivos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
clientesInactivos.url = (options?: RouteQueryOptions) => {
    return clientesInactivos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
clientesInactivos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clientesInactivos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
clientesInactivos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clientesInactivos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
    const clientesInactivosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clientesInactivos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
        clientesInactivosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clientesInactivos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DashboardStatsController::clientesInactivos
 * @see app/Http/Controllers/Api/DashboardStatsController.php:185
 * @route '/api/dashboard/clientes-inactivos'
 */
        clientesInactivosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clientesInactivos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clientesInactivos.form = clientesInactivosForm
const DashboardStatsController = { clients, retenciones, cuentasPorCobrar, promotionArticles, orderStats, clientesSinPedidos, clientesInactivos }

export default DashboardStatsController