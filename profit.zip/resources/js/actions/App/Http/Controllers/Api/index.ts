import DashboardStatsController from './DashboardStatsController'
const Api = {
    DashboardStatsController: Object.assign(DashboardStatsController, DashboardStatsController),
}

export default Api