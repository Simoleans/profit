import DashboardController from './DashboardController'
import UserController from './UserController'
import ClientController from './ClientController'
import ArticleController from './ArticleController'
import HeaderController from './HeaderController'
import Settings from './Settings'
import Auth from './Auth'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
UserController: Object.assign(UserController, UserController),
ClientController: Object.assign(ClientController, ClientController),
ArticleController: Object.assign(ArticleController, ArticleController),
HeaderController: Object.assign(HeaderController, HeaderController),
Settings: Object.assign(Settings, Settings),
Auth: Object.assign(Auth, Auth),
}

export default Controllers