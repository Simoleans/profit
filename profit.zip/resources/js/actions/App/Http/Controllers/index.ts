import DashboardController from './DashboardController'
import Api from './Api'
import UserController from './UserController'
import ClientController from './ClientController'
import ClientesSinPedidosController from './ClientesSinPedidosController'
import ArticleController from './ArticleController'
import HeaderController from './HeaderController'
import Settings from './Settings'
import Auth from './Auth'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
Api: Object.assign(Api, Api),
UserController: Object.assign(UserController, UserController),
ClientController: Object.assign(ClientController, ClientController),
ClientesSinPedidosController: Object.assign(ClientesSinPedidosController, ClientesSinPedidosController),
ArticleController: Object.assign(ArticleController, ArticleController),
HeaderController: Object.assign(HeaderController, HeaderController),
Settings: Object.assign(Settings, Settings),
Auth: Object.assign(Auth, Auth),
}

export default Controllers