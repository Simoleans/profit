import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\HeaderController::index
 * @see app/Http/Controllers/HeaderController.php:82
 * @route '/orders'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::index
 * @see app/Http/Controllers/HeaderController.php:82
 * @route '/orders'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::index
 * @see app/Http/Controllers/HeaderController.php:82
 * @route '/orders'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::index
 * @see app/Http/Controllers/HeaderController.php:82
 * @route '/orders'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::index
 * @see app/Http/Controllers/HeaderController.php:82
 * @route '/orders'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::index
 * @see app/Http/Controllers/HeaderController.php:82
 * @route '/orders'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::index
 * @see app/Http/Controllers/HeaderController.php:82
 * @route '/orders'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\HeaderController::create
 * @see app/Http/Controllers/HeaderController.php:120
 * @route '/orders/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/orders/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::create
 * @see app/Http/Controllers/HeaderController.php:120
 * @route '/orders/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::create
 * @see app/Http/Controllers/HeaderController.php:120
 * @route '/orders/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::create
 * @see app/Http/Controllers/HeaderController.php:120
 * @route '/orders/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::create
 * @see app/Http/Controllers/HeaderController.php:120
 * @route '/orders/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::create
 * @see app/Http/Controllers/HeaderController.php:120
 * @route '/orders/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::create
 * @see app/Http/Controllers/HeaderController.php:120
 * @route '/orders/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\HeaderController::store
 * @see app/Http/Controllers/HeaderController.php:129
 * @route '/orders'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HeaderController::store
 * @see app/Http/Controllers/HeaderController.php:129
 * @route '/orders'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::store
 * @see app/Http/Controllers/HeaderController.php:129
 * @route '/orders'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HeaderController::store
 * @see app/Http/Controllers/HeaderController.php:129
 * @route '/orders'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HeaderController::store
 * @see app/Http/Controllers/HeaderController.php:129
 * @route '/orders'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\HeaderController::show
 * @see app/Http/Controllers/HeaderController.php:260
 * @route '/orders/{fact_num}'
 */
export const show = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/orders/{fact_num}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::show
 * @see app/Http/Controllers/HeaderController.php:260
 * @route '/orders/{fact_num}'
 */
show.url = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact_num: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fact_num: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact_num: args.fact_num,
                }

    return show.definition.url
            .replace('{fact_num}', parsedArgs.fact_num.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::show
 * @see app/Http/Controllers/HeaderController.php:260
 * @route '/orders/{fact_num}'
 */
show.get = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::show
 * @see app/Http/Controllers/HeaderController.php:260
 * @route '/orders/{fact_num}'
 */
show.head = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::show
 * @see app/Http/Controllers/HeaderController.php:260
 * @route '/orders/{fact_num}'
 */
    const showForm = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::show
 * @see app/Http/Controllers/HeaderController.php:260
 * @route '/orders/{fact_num}'
 */
        showForm.get = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::show
 * @see app/Http/Controllers/HeaderController.php:260
 * @route '/orders/{fact_num}'
 */
        showForm.head = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\HeaderController::edit
 * @see app/Http/Controllers/HeaderController.php:283
 * @route '/orders/{fact_num}/edit'
 */
export const edit = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/orders/{fact_num}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::edit
 * @see app/Http/Controllers/HeaderController.php:283
 * @route '/orders/{fact_num}/edit'
 */
edit.url = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact_num: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fact_num: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact_num: args.fact_num,
                }

    return edit.definition.url
            .replace('{fact_num}', parsedArgs.fact_num.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::edit
 * @see app/Http/Controllers/HeaderController.php:283
 * @route '/orders/{fact_num}/edit'
 */
edit.get = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::edit
 * @see app/Http/Controllers/HeaderController.php:283
 * @route '/orders/{fact_num}/edit'
 */
edit.head = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::edit
 * @see app/Http/Controllers/HeaderController.php:283
 * @route '/orders/{fact_num}/edit'
 */
    const editForm = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::edit
 * @see app/Http/Controllers/HeaderController.php:283
 * @route '/orders/{fact_num}/edit'
 */
        editForm.get = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::edit
 * @see app/Http/Controllers/HeaderController.php:283
 * @route '/orders/{fact_num}/edit'
 */
        editForm.head = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\HeaderController::update
 * @see app/Http/Controllers/HeaderController.php:314
 * @route '/orders/{fact_num}'
 */
export const update = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/orders/{fact_num}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\HeaderController::update
 * @see app/Http/Controllers/HeaderController.php:314
 * @route '/orders/{fact_num}'
 */
update.url = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact_num: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fact_num: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact_num: args.fact_num,
                }

    return update.definition.url
            .replace('{fact_num}', parsedArgs.fact_num.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::update
 * @see app/Http/Controllers/HeaderController.php:314
 * @route '/orders/{fact_num}'
 */
update.put = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\HeaderController::update
 * @see app/Http/Controllers/HeaderController.php:314
 * @route '/orders/{fact_num}'
 */
    const updateForm = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HeaderController::update
 * @see app/Http/Controllers/HeaderController.php:314
 * @route '/orders/{fact_num}'
 */
        updateForm.put = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\HeaderController::destroy
 * @see app/Http/Controllers/HeaderController.php:406
 * @route '/orders/{fact_num}'
 */
export const destroy = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/orders/{fact_num}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\HeaderController::destroy
 * @see app/Http/Controllers/HeaderController.php:406
 * @route '/orders/{fact_num}'
 */
destroy.url = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact_num: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fact_num: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact_num: args.fact_num,
                }

    return destroy.definition.url
            .replace('{fact_num}', parsedArgs.fact_num.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::destroy
 * @see app/Http/Controllers/HeaderController.php:406
 * @route '/orders/{fact_num}'
 */
destroy.delete = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\HeaderController::destroy
 * @see app/Http/Controllers/HeaderController.php:406
 * @route '/orders/{fact_num}'
 */
    const destroyForm = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HeaderController::destroy
 * @see app/Http/Controllers/HeaderController.php:406
 * @route '/orders/{fact_num}'
 */
        destroyForm.delete = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\HeaderController::approve
 * @see app/Http/Controllers/HeaderController.php:513
 * @route '/orders/{fact_num}/approve'
 */
export const approve = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/orders/{fact_num}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HeaderController::approve
 * @see app/Http/Controllers/HeaderController.php:513
 * @route '/orders/{fact_num}/approve'
 */
approve.url = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact_num: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fact_num: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact_num: args.fact_num,
                }

    return approve.definition.url
            .replace('{fact_num}', parsedArgs.fact_num.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::approve
 * @see app/Http/Controllers/HeaderController.php:513
 * @route '/orders/{fact_num}/approve'
 */
approve.post = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HeaderController::approve
 * @see app/Http/Controllers/HeaderController.php:513
 * @route '/orders/{fact_num}/approve'
 */
    const approveForm = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HeaderController::approve
 * @see app/Http/Controllers/HeaderController.php:513
 * @route '/orders/{fact_num}/approve'
 */
        approveForm.post = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\HeaderController::resendEmail
 * @see app/Http/Controllers/HeaderController.php:556
 * @route '/orders/{fact_num}/resend-email'
 */
export const resendEmail = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendEmail.url(args, options),
    method: 'post',
})

resendEmail.definition = {
    methods: ["post"],
    url: '/orders/{fact_num}/resend-email',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\HeaderController::resendEmail
 * @see app/Http/Controllers/HeaderController.php:556
 * @route '/orders/{fact_num}/resend-email'
 */
resendEmail.url = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fact_num: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    fact_num: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fact_num: args.fact_num,
                }

    return resendEmail.definition.url
            .replace('{fact_num}', parsedArgs.fact_num.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::resendEmail
 * @see app/Http/Controllers/HeaderController.php:556
 * @route '/orders/{fact_num}/resend-email'
 */
resendEmail.post = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendEmail.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\HeaderController::resendEmail
 * @see app/Http/Controllers/HeaderController.php:556
 * @route '/orders/{fact_num}/resend-email'
 */
    const resendEmailForm = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resendEmail.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\HeaderController::resendEmail
 * @see app/Http/Controllers/HeaderController.php:556
 * @route '/orders/{fact_num}/resend-email'
 */
        resendEmailForm.post = (args: { fact_num: string | number } | [fact_num: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resendEmail.url(args, options),
            method: 'post',
        })
    
    resendEmail.form = resendEmailForm
/**
* @see \App\Http\Controllers\HeaderController::searchClients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
export const searchClients = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchClients.url(options),
    method: 'get',
})

searchClients.definition = {
    methods: ["get","head"],
    url: '/search-clients',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::searchClients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
searchClients.url = (options?: RouteQueryOptions) => {
    return searchClients.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::searchClients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
searchClients.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchClients.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::searchClients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
searchClients.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: searchClients.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::searchClients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
    const searchClientsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: searchClients.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::searchClients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
        searchClientsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: searchClients.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::searchClients
 * @see app/Http/Controllers/HeaderController.php:432
 * @route '/search-clients'
 */
        searchClientsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: searchClients.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    searchClients.form = searchClientsForm
/**
* @see \App\Http\Controllers\HeaderController::searchArticles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
export const searchArticles = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchArticles.url(options),
    method: 'get',
})

searchArticles.definition = {
    methods: ["get","head"],
    url: '/search-articles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::searchArticles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
searchArticles.url = (options?: RouteQueryOptions) => {
    return searchArticles.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::searchArticles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
searchArticles.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: searchArticles.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::searchArticles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
searchArticles.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: searchArticles.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::searchArticles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
    const searchArticlesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: searchArticles.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::searchArticles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
        searchArticlesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: searchArticles.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::searchArticles
 * @see app/Http/Controllers/HeaderController.php:495
 * @route '/search-articles'
 */
        searchArticlesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: searchArticles.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    searchArticles.form = searchArticlesForm
/**
* @see \App\Http\Controllers\HeaderController::checkClient
 * @see app/Http/Controllers/HeaderController.php:451
 * @route '/check-client'
 */
export const checkClient = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkClient.url(options),
    method: 'get',
})

checkClient.definition = {
    methods: ["get","head"],
    url: '/check-client',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::checkClient
 * @see app/Http/Controllers/HeaderController.php:451
 * @route '/check-client'
 */
checkClient.url = (options?: RouteQueryOptions) => {
    return checkClient.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::checkClient
 * @see app/Http/Controllers/HeaderController.php:451
 * @route '/check-client'
 */
checkClient.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: checkClient.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::checkClient
 * @see app/Http/Controllers/HeaderController.php:451
 * @route '/check-client'
 */
checkClient.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: checkClient.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::checkClient
 * @see app/Http/Controllers/HeaderController.php:451
 * @route '/check-client'
 */
    const checkClientForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: checkClient.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::checkClient
 * @see app/Http/Controllers/HeaderController.php:451
 * @route '/check-client'
 */
        checkClientForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkClient.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::checkClient
 * @see app/Http/Controllers/HeaderController.php:451
 * @route '/check-client'
 */
        checkClientForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: checkClient.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    checkClient.form = checkClientForm
/**
* @see \App\Http\Controllers\HeaderController::debugUserData
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
export const debugUserData = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: debugUserData.url(options),
    method: 'get',
})

debugUserData.definition = {
    methods: ["get","head"],
    url: '/debug-user-data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HeaderController::debugUserData
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
debugUserData.url = (options?: RouteQueryOptions) => {
    return debugUserData.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HeaderController::debugUserData
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
debugUserData.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: debugUserData.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HeaderController::debugUserData
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
debugUserData.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: debugUserData.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HeaderController::debugUserData
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
    const debugUserDataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: debugUserData.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HeaderController::debugUserData
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
        debugUserDataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: debugUserData.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HeaderController::debugUserData
 * @see app/Http/Controllers/HeaderController.php:469
 * @route '/debug-user-data'
 */
        debugUserDataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: debugUserData.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    debugUserData.form = debugUserDataForm
const HeaderController = { index, create, store, show, edit, update, destroy, approve, resendEmail, searchClients, searchArticles, checkClient, debugUserData }

export default HeaderController